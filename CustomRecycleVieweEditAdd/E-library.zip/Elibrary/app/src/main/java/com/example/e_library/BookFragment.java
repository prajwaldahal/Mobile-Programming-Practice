package com.example.e_library;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresPermission;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BookFragment extends Fragment {
    RecyclerView recyclerView;
    Context context;

    private ProgressBar progressBar;
    List<Book>books;
    BookAdapter bookAdapter;
    public BookFragment(Context context) {
        this.context = context;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view= inflater.inflate(R.layout.fragment_book, container, false);
        progressBar = view.findViewById(R.id.progress_bar);

        books=new ArrayList<>();

            getBooks();

        recyclerView=view.findViewById(R.id.book_list);
        LinearLayoutManager linearLayoutManager= new LinearLayoutManager(context);
        recyclerView.setLayoutManager(linearLayoutManager);

        bookAdapter=new BookAdapter(this,context,books);
        recyclerView.setAdapter(bookAdapter);

        bookAdapter.setOnItemClickListener(position -> {
            showDialog(position);
        });

        return  view;

    }

    private void showDialog(int position) {
        TextView name,publisher,isbnno,rent,author;
        ImageView imageView;
        Dialog dialog=new Dialog(context);
        dialog.setContentView(R.layout.book_dialog_layout);

        name=dialog.findViewById(R.id.book_dialog_name);
        publisher=dialog.findViewById(R.id.dialog_book_publisher);
        isbnno=dialog.findViewById(R.id.dialog_book_id);
        rent=dialog.findViewById(R.id.dialog_book_rent);
        author=dialog.findViewById(R.id.dialog_book_author);
        imageView=dialog.findViewById(R.id.dialog_cover_image);

        name.setText(books.get(position).getName());
        publisher.setText(books.get(position).getPublisher());
        name.setText(books.get(position).getName());
        isbnno.setText(books.get(position).getIsbnno());
        rent.setText("Rs."+books.get(position).getRent()+" per month");
        author.setText(books.get(position).getAuthor());
        Glide.with(context)
                .load("https://conforming-entrance.000webhostapp.com/elib/coverpic/"+books.get(0).getImg())
                .into(imageView);

        dialog.show();
    }

    private void getBooks() {

        progressBar.setVisibility(ProgressBar.VISIBLE);

        APIServices elibBook=RetrofitBook.getRetrofitInstance(context);
        Call<List<Book>> call = elibBook.getAllBook();

        call.enqueue(new Callback<List<Book>>() {
            @Override
            public void onResponse(@NonNull Call<List<Book>> call, Response<List<Book>> response) {
                progressBar.setVisibility(ProgressBar.GONE);
                if (response.isSuccessful()) {
                    List<Book> fetchedBooks = response.body();
                    books.clear();
                    books.addAll(fetchedBooks);
                    bookAdapter.notifyDataSetChanged();

                    Log.d("books", "onResponse: "+ books.get(0));
                } else {
                    Toast.makeText(context, "something went wrong", Toast.LENGTH_SHORT).show();
                    Log.d("fail", "onResponse: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<List<Book>> call, Throwable t) {
                Toast.makeText(context, "something went wrong", Toast.LENGTH_SHORT).show();
                Log.d("API Call Error", t.getMessage(), t);
            }
        });
    }

    public FragmentManager getSupportFragmentManager(){
        return getParentFragmentManager();
    }
}