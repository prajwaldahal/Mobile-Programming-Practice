package com.example.e_library;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

public class RentedFragment extends Fragment {
    RecyclerView recyclerView;
    Context context;
    List<RentedBook> rentedBooks;

    public RentedFragment(Context context) {
        this.context = context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        View view=inflater.inflate(R.layout.fragment_rented, container, false);

        recyclerView=view.findViewById(R.id.rented_book_list);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(linearLayoutManager);

        rentedBooks=new ArrayList<>();
        saveBooks();


        RentedBookAdapter rentedBookAdapter=new RentedBookAdapter(context,rentedBooks);
        recyclerView.setAdapter(rentedBookAdapter);


        return  view;
    }

    private void saveBooks() {

        String[] bookNames = {
                "To Kill a Mockingbird",
                "1984",
                "The Great Gatsby",
                "Pride and Prejudice",
                "Harry Potter and the Sorcerer's Stone",
                "Clean Code: A Handbook of Agile Software Craftsmanship",
                "Cracking the Coding Interview: 189 Programming Questions and Solutions",
                "Design Patterns: Elements of Reusable Object-Oriented Software"
        };

        String[] authors = {
                "Agatha Christie",
                "Ernest Hemingway",
                "J.R.R. Tolkien",
                "Maya Angelou",
                "Stephen King",
                "Jane Austen",
                "Gabriel Garcia Marquez",
                "Harper Lee"
        };

        String[] isbnNos= {
                "978-0-7475-5100-8",
                "978-0-451-52681-7",
                "978-0-06-112008-4",
                "978-0-553-21411-0",
                "978-0-06-249853-8",
                "978-1-56881-234-2",
                "978-0-7432-4727-9",
                "978-0-9946388-0-5"
        };

        String[] urls ={


                "https://farm7.staticflickr.com/6089/6115759179_86316c08ff_z_d.jpg",

                "https://farm2.staticflickr.com/1090/4595137268_0e3f2b9aa7_z_d.jpg",

                "https://farm3.staticflickr.com/2220/1572613671_7311098b76_z_d.jpg",

                "https://i.imgur.com/OnwEDW3.jpg",

                "https://farm9.staticflickr.com/8505/8441256181_4e98d8bff5_z_d.jpg",

                "https://farm4.staticflickr.com/3075/3168662394_7d7103de7d_z_d.jpg",


                "https://farm8.staticflickr.com/7377/9359257263_81b080a039_z_d.jpg",

                "https://i.imgur.com/CzXTtJV.jpg"

        };


        for (int i = 0; i < bookNames.length; i++) {
            RentedBook rentedBook= new RentedBook(isbnNos[i],bookNames[i],authors[i],urls[i]);
            rentedBooks.add(rentedBook);
        }


    }
}