package com.example.e_library;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Arrays;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "elibrary_db";
    private static final int DB_VERSION = 1;
    private Context context;

    public DatabaseHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.context=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_QUERY = "CREATE TABLE rented_book(isbnno VARCHAR(14) PRIMARY KEY, name TEXT, author TEXT, image TEXT,file Text,expiry_date Text)";
        db.execSQL(CREATE_TABLE_QUERY);
        Toast.makeText(context, "", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String DROP_TABLE_QUERY = "DROP TABLE IF EXISTS rented_book";
        db.execSQL(DROP_TABLE_QUERY);
        onCreate(db);
    }

    public boolean saveBook(RentedBook book){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("isbnno",book.getId());
        values.put("name",book.getName());
        values.put("author",book.getAuthor());
        values.put("image",book.getImgurl());
        values.put("file",book.getFileurl());
        values.put("expiry_date",book.getExpiryDate());

        long result = db.insert("rented_book", null, values);
        db.close();
        return result > -1;
    }


    public void deleteContact(String isbnno){
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause = "isbnno=?";
        String[] whereArgs = {String.valueOf(isbnno)};
        db.delete("rented_book", whereClause, whereArgs);
        db.close();
    }

    public ArrayList<RentedBook> getAllContacts(){
        ArrayList<RentedBook> rentedBookList = new ArrayList<>();

        SQLiteDatabase database = this.getReadableDatabase();

        Cursor cursor = database.query("rented_book", null, null, null, null, null, null);


        if (cursor.moveToFirst()) {
            int isbnIndex = cursor.getColumnIndex("isbnno");
            int nameIndex = cursor.getColumnIndex("name");
            int authorIndex = cursor.getColumnIndex("author");
            int imageIndex=cursor.getColumnIndex("image");
            int fileIndex=cursor.getColumnIndex("file");
            int dateIndex=cursor.getColumnIndex("expiry_date");


            do {

                String isbnno= isbnIndex!=-1 ? cursor.getString(isbnIndex):null;
                String name =  nameIndex !=-1?cursor.getString(nameIndex):null ;
                String author = authorIndex != -1 ? cursor.getString(authorIndex) : null;
                String image = imageIndex != -1 ? cursor.getString(imageIndex) : null;
                String file = fileIndex != -1 ? cursor.getString(fileIndex) : null;
                String date=dateIndex != -1 ? cursor.getString(dateIndex):null;
                RentedBook book= new RentedBook(isbnno,name,author,date,image,file);
                rentedBookList.add(book);

            }while(cursor.moveToNext());

            cursor.close();
        }

        database.close();
        return rentedBookList;
    }
}
