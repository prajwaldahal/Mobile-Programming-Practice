package com.example.e_library;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.List;

public class RentedBookAdapter extends RecyclerView.Adapter<RentedBookAdapter.ViewHolder> {
    private Context context;
    private List<RentedBook> books;

    public RentedBookAdapter(Context context,  List<RentedBook> books) {
        this.context = context;
        this.books = books;
    }

    @NonNull
    @Override

    public RentedBookAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
              View view=  LayoutInflater.from(context).inflate(R.layout.rented_book_layout,parent,false);
              return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RentedBookAdapter.ViewHolder holder, int position) {
        holder.bind(books.get(position));
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView bookAuth,bookName,bookId;
        Button readBook;
        ImageView cover;
        public ViewHolder(@NonNull View itemView) {

            super(itemView);

            bookName=itemView.findViewById(R.id.rented_book_name);
            bookAuth=itemView.findViewById(R.id.rented_book_author);
            bookId=itemView.findViewById(R.id.rented_book_id);
            readBook=itemView.findViewById(R.id.read_book);
            cover=itemView.findViewById(R.id.cover_image);

        }

        public void bind(RentedBook rentedBook) {
            bookName.setText(rentedBook.getName());
            bookAuth.setText(rentedBook.getAuthor());
            bookId.setText(rentedBook.getId());
            Glide.with(context)
                    .load(rentedBook.getImgurl())
                    .into(cover);
        }
    }
}
