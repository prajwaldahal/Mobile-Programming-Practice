package com.example.e_library;

import android.content.Context;

import okhttp3.Cache;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitBook {
    private static final long CACHE_SIZE = 10 * 1024 * 1024;
    public static APIServices getRetrofitInstance(Context context){
        Cache cache = new Cache(context.getCacheDir(), CACHE_SIZE);

        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .cache(cache)
                .build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://conforming-entrance.000webhostapp.com/api/")
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        APIServices apiServices = retrofit.create(APIServices.class);
        System.out.println(apiServices);
        return apiServices;
    }
}
