package com.example.e_library;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.ViewHolder> {
    private Context context;
    private List<Book> books;
    private BookFragment fragment;

    private ItemClickListener itemClickListener;
    public BookAdapter(BookFragment fragment,Context context,  List<Book> books) {
        this.context = context;
        this.books = books;
        this.fragment=fragment;
    }

    public interface ItemClickListener {
        void onItemClick(int position);
    }

    public void setOnItemClickListener(BookAdapter.ItemClickListener listener) {
        this.itemClickListener = listener;
    }

    @NonNull
    @Override

    public BookAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view=  LayoutInflater.from(context).inflate(R.layout.book_layout,parent,false);
        return new BookAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookAdapter.ViewHolder holder, int position) {
        holder.bind(books.get(position));
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView bookAuth,bookName,bookRent;
        Button rentBook;
        ImageView cover;
        public ViewHolder(@NonNull View itemView) {

            super(itemView);

            bookName=itemView.findViewById(R.id.book_name);
            bookAuth=itemView.findViewById(R.id.book_author);
            rentBook=itemView.findViewById(R.id.btn_rent_book);
            cover=itemView.findViewById(R.id.book_cover_image);
            bookRent=itemView.findViewById(R.id.book_rent);


            itemView.setOnClickListener(v -> {
                if (itemClickListener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        itemClickListener.onItemClick(position);
                    }
                }
            });
        }

        public void bind(Book book) {
            bookName.setText(book.getName());
            System.out.println(book);
            bookAuth.setText(book.getAuthor());
            bookRent.setText(book.getRent()+" per month");
            Glide.with(context)
                    .load("https://conforming-entrance.000webhostapp.com/elib/coverpic/"+book.getImg())
                    .into(cover);

            rentBook.setOnClickListener(v -> {
                Dialog dialog= new Dialog(context);
                dialog.setContentView(R.layout.buy_dialog_layout);
                dialog.show();
            });
        }
    }
}
