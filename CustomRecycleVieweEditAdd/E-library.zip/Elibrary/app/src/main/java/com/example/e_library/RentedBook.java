package com.example.e_library;

public class RentedBook {
    private String name;
    private String id;
    private String img;
    private String file;
    private String author;

    private String expiryDate;


    public RentedBook(String id, String name, String author, String expiryDate, String img, String file) {
        this.name = name;
        this.id = id;
        this.img = img;
        this.file = file;
        this.author = author;
        this.expiryDate=expiryDate;
    }

    public RentedBook(String id,String name, String author, String img) {
        this.name = name;
        this.id = id;
        this.img = img;
        this.author=author;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImgurl() {
        return img;
    }

    public void setImgurl(String img) {
        this.img = img;
    }

    public String getFileurl() {
        return file;
    }

    public void setFileurl(String file) {
        this.file = file;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }
}
